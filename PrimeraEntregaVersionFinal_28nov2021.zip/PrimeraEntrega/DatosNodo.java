package PrimeraEntrega;

public class DatosNodo {
	private float costo;
	private Estado estado;
	private int IDpadre;
	private Accion accion;
	private int profundidad;
	private float heuristica;
	private float f;
	
	public DatosNodo(int iDpadre, int profundidad, float costo, Estado estado, Accion accion, float heuristica) {
		super();
		IDpadre = iDpadre;
		this.profundidad = profundidad;
		this.costo = costo;
		this.estado = estado;
		this.accion = accion;
		this.heuristica = heuristica;
	}
	
	public int getIDpadre() {
		return IDpadre;
	}
	public void setIDpadre(int iDpadre) {
		IDpadre = iDpadre;
	}
	public int getProfundidad() {
		return profundidad;
	}
	public void setProfundidad(int profundidad) {
		this.profundidad = profundidad;
	}
	public float getCosto() {
		return costo;
	}
	public void setCosto(float costo) {
		this.costo = costo;
	}
	public Estado getEstado() {
		return estado;
	}
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	public Accion getAccion() {
		return accion;
	}
	public void setAccion(Accion accion) {
		this.accion = accion;
	}
	public float getHeuristica() {
		return heuristica;
	}
	public void setHeuristica(float heuristica) {
		this.heuristica = heuristica;
	}
	public float getF() {
		return f;
	}
	public void setF(float f) {
		this.f = f;
	}
	
	

	
}
