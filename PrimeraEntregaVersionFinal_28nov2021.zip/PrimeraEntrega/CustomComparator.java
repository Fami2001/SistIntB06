package PrimeraEntrega;

import java.util.Comparator;

public class CustomComparator implements Comparator<Nodo> {
    @Override
    public int compare(Nodo n1, Nodo n2) {
    	if(n1.getDatosNodo().getF() == n2.getDatosNodo().getF()) {
    		String n1Id = "" + n1.getID();
    		String n2Id = "" + n2.getID();
    	return n1Id.compareTo(n2Id);
    	}
    	else {
    		return Float.toString(n1.getDatosNodo().getF()).compareTo(Float.toString(n2.getDatosNodo().getF()));
    	}
    }
}