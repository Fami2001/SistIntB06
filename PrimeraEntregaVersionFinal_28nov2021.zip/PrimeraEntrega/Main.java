package PrimeraEntrega;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;
import java.util.concurrent.LinkedBlockingQueue;

import com.google.gson.reflect.TypeToken;



import com.google.gson.*;


public class Main {
	public static Scanner TECLADO=new Scanner(System.in);
	public static void main(String[]args) throws IOException, NoSuchAlgorithmException {



		JuegoBotellas juegoBotellas = pasarFicheroAClaseJuegoBotella();	
		System.out.println(juegoBotellas.getId());
		System.out.println(juegoBotellas.getTamanioBotella());
		System.out.println(juegoBotellas.getJsonState());

		boolean cerrarMenu=false;
		while(!cerrarMenu) {
			System.out.println("Seleccione un tipo de busqueda:");
			System.out.println("0-Anchura");
			System.out.println("1-Costo Uniforme");
			System.out.println("2-Profundidad Acotada");
			System.out.println("3-Greedy");
			System.out.println("4-A*");
			System.out.println("5-Cerrar men�");
			int opcionBusqueda=TECLADO.nextInt();
			switch (opcionBusqueda) {
			case 0: 
				String solucion = busqueda2(juegoBotellas, opcionBusqueda);
				pasarSolucionAArchivo("Anchura.txt", solucion);
				break;
			case 1:
				String solucion2 = busqueda2(juegoBotellas, opcionBusqueda);
				pasarSolucionAArchivo("CosteUniforme.txt", solucion2);
				break;
			case 2:
				String solucion3 = busqueda2(juegoBotellas, opcionBusqueda);
				pasarSolucionAArchivo("ProfundidadAcotada.txt", solucion3);
				break;
			case 3 :
				String solucion4 = busqueda2(juegoBotellas, opcionBusqueda);
				pasarSolucionAArchivo("Greedy.txt", solucion4);
				break;
			case 4 :
				String solucion5 = busqueda2(juegoBotellas, opcionBusqueda);
				pasarSolucionAArchivo("AEstrella.txt", solucion5);
				break;				
			case 5:
				cerrarMenu=true;
				break;
			default:
				break;

			}
		}
	}




	public static void JSONtoJAVA(ArrayList<Botella> listaBotellas,JuegoBotellas juego) {
		Gson gson = new Gson();
		final java.lang.reflect.Type tipoListaPilasBotellas =  new TypeToken<List<Stack<int[]>>>(){}.getType();
		ArrayList<Stack<int[]>> listaPilasJSONtoJava= gson.fromJson(juego.getJsonState(), (java.lang.reflect.Type) tipoListaPilasBotellas);

		Iterator<Stack<int[]>> iteradorPilas = listaPilasJSONtoJava.iterator();
		int contadorID=0;
		while(iteradorPilas.hasNext()) {
			Stack<int[]> botellaLiquidos = iteradorPilas.next();
			Stack<int[]> botellaAux = invertirPila(botellaLiquidos);
			Botella botella=new Botella(String.valueOf(contadorID),botellaAux,juego.getTamanioBotella());
			contadorID++;
			listaBotellas.add(botella);
		}
	}

	public static String JAVAtoStringJSON(ArrayList<Botella> listaBotellas) {
		String stringJson = "";
		ArrayList<Stack<int[]>> listaPilasBotellas = new ArrayList<Stack<int[]>>();
		Iterator<Botella> iteradorBotellas = listaBotellas.iterator();
		while(iteradorBotellas.hasNext()) {
			Botella botella = clonarBotella(iteradorBotellas.next());
			listaPilasBotellas.add(invertirPila(botella.getPilaLiquidos()));
		}
		Gson gson = new Gson();
		final java.lang.reflect.Type tipoListaPilasBotellas =  new TypeToken<List<Stack<int[]>>>(){}.getType();
		stringJson =  gson.toJson(listaPilasBotellas);
		return stringJson;
	}


	public static int calcularCantidadLiquidoPila(Stack<int[]> botella) {
		Iterator<int[]> iteradorLiquidos = botella.iterator();
		int contadorCantidad=0;
		while(iteradorLiquidos.hasNext()) {
			int[] liquido = iteradorLiquidos.next();
			contadorCantidad = contadorCantidad + liquido[1];
		}
		return contadorCantidad;
	}


	public static boolean Es_Valido(Botella Botella_origen, Botella Botella_destino) {
		boolean esPosible=false;
		if(!Botella_origen.getPilaLiquidos().isEmpty())	{
			if(Botella_destino.getPilaLiquidos().isEmpty()) {
				esPosible=true;
			}else if ((calcularCantidadLiquidoPila(Botella_destino.getPilaLiquidos()) + Botella_origen.getPilaLiquidos().peek()[1]<=Botella_destino.getCapacidadMaxima()) && (Botella_origen.getPilaLiquidos().peek()[0]==Botella_destino.getPilaLiquidos().peek()[0])) {
				esPosible=true;
			}
		}
		return esPosible;
	}


	public static int AccionSinCantidad (Botella Botella_origen, Botella Botella_destino) {
		int cantidad=0;
		if(Es_Valido(Botella_origen,Botella_destino)) {			
			int[] liquido = Botella_origen.getPilaLiquidos().pop();
			if(!Botella_destino.getPilaLiquidos().isEmpty()) {
				if (Botella_destino.getPilaLiquidos().peek()[0] == liquido[0]){

					int [] liquidoLlenar= {liquido[0],liquido[1] + Botella_destino.getPilaLiquidos().pop()[1]};						
					Botella_destino.getPilaLiquidos().push(liquidoLlenar);
					cantidad=liquido[1];
				}
				else {
					Botella_destino.getPilaLiquidos().push(liquido);
					cantidad = liquido[1];
				}
			}
			else {
				Botella_destino.getPilaLiquidos().push(liquido);
				cantidad = liquido[1];
			}			
		}
		return cantidad;
	}


	public static JuegoBotellas pasarFicheroAClaseJuegoBotella() throws JsonIOException, JsonSyntaxException, FileNotFoundException {
		JsonParser parser = new JsonParser();

		Object obj = parser.parse(new FileReader("C:\\Users\\rober\\Downloads\\p0.json"));
		JsonObject jsonObject =  (JsonObject) obj;
		JsonElement id =  jsonObject.get("id");
		String stringID = id.toString();
		JsonElement tamanioBotella =  jsonObject.get("bottleSize");
		int tamanio= Integer.parseInt((tamanioBotella.toString()));
		JsonElement jsonState =  jsonObject.get("initState");
		String estadoInicial = jsonState.toString();

		JuegoBotellas juegoBotellas = new JuegoBotellas(stringID, tamanio, estadoInicial);


		return juegoBotellas;
	}








	public static ArrayList <Sucesor> Sucesores(Estado estado){
		ArrayList<Botella> listaBotellas = estado.getListaBotellas();
		ArrayList<Sucesor> Resultado = new ArrayList<Sucesor>();
		for(int i=0;i<listaBotellas.size();i++) {
			for(int j=0;j<listaBotellas.size();j++) {
				if(i!=j) {
					if(Es_Valido(estado.getListaBotellas().get(i),estado.getListaBotellas().get(j))) {
						ArrayList<Botella> ListaAux = new ArrayList<Botella>();
						clonarLista(listaBotellas, ListaAux);
						Botella botellaAux1 = clonarBotella(ListaAux.get(i)); 
						Botella botellaAux2 = clonarBotella(ListaAux.get(j)); 					
						int cantidad = AccionSinCantidad(ListaAux.get(i),ListaAux.get(j));					
						Accion accion = new Accion(botellaAux1,botellaAux2,cantidad);
						Estado estadoAux = new Estado (ListaAux);
						//estadoAux.calculoCoste("");
						Sucesor sucesor = new Sucesor(accion,estadoAux,1);
						Resultado.add(sucesor);						
					}
				}

			}

		}	
		return Resultado;
	}

	/*public static void Sucesores(Nodo padre,Queue<Nodo> frontera, Visitados visitados ) throws NoSuchAlgorithmException {
		if(!visitados.pertenece(padre.getDatosNodo().getEstado()) || padre.getID() != -1) {
			ArrayList<Botella> listaBotellas = padre.getDatosNodo().getEstado().getListaBotellas();
			for(int i = 0; i<padre.getDatosNodo().getEstado().getListaBotellas().size(); i++) {
				for(int j = 0; j<padre.getDatosNodo().getEstado().getListaBotellas().size(); j++) {
					if(Es_Valido(padre.getDatosNodo().getEstado().getListaBotellas().get(i),padre.getDatosNodo().getEstado().getListaBotellas().get(j))) {
						ArrayList<Botella> ListaAux = new ArrayList<Botella>();
						clonarLista(listaBotellas, ListaAux);
						Botella botellaAux1 = clonarBotella(ListaAux.get(i)); 
						Botella botellaAux2 = clonarBotella(ListaAux.get(j)); 					
						float cantidad = AccionSinCantidad(ListaAux.get(i),ListaAux.get(j));					
						Accion accion = new Accion(botellaAux1,botellaAux2,cantidad);
						Estado estadoAux = new Estado (ListaAux);
						//estadoAux.calculoCoste("");
						Sucesor sucesor = new Sucesor(accion,estadoAux,1);
						DatosNodo datosNodo = new DatosNodo (padre.getID(),padre.getDatosNodo().getProfundidad()+1,padre.getDatosNodo().getCosto()+sucesor.getCosto(),sucesor.getNuevoEstado(),sucesor.getAccion(),0);
						Nodo nodoHijo = new Nodo (datosNodo);
						nodoHijo.calcularFAnchura();
						frontera.add(nodoHijo);
						//ordenarColaNodosPorF(frontera);
					}
				}

			}

		}
	}*/



	public static boolean esObjetivo(Nodo nodo) {
		ArrayList<Botella> listaBotellas = nodo.getDatosNodo().getEstado().getListaBotellas();
		boolean objetivo = false;
		int contador = 0;
		Iterator<Botella> iteradorBotellas = listaBotellas.iterator();
		while(iteradorBotellas.hasNext()) {
			Botella botella = iteradorBotellas.next();
			if(botella.getPilaLiquidos().isEmpty() || botella.getPilaLiquidos().peek()[1] == botella.getCapacidadMaxima()) {
				contador++;
			}
		}
		if (contador==listaBotellas.size()) {
			objetivo = true;
		}
		return objetivo;

	}




	public static Nodo makeNode(JuegoBotellas problem,int opcionBusqueda) {
		ArrayList<Botella> listaBotellas = new ArrayList<Botella>();
		JSONtoJAVA(listaBotellas,problem);

		Estado estadoInicial = new Estado(listaBotellas);
		Accion accionInicial = null;
		DatosNodo datosNodoInicial = new DatosNodo(0,0,0,estadoInicial,accionInicial,0);
		Nodo nodoInicial = new Nodo (datosNodoInicial,0);
		nodoInicial.getDatosNodo().setIDpadre(-1);
		nodoInicial.setID(0);
		
		if(opcionBusqueda == 0) {
			nodoInicial.getDatosNodo().setHeuristica(calcularHeuristica(nodoInicial));
		}

		if(opcionBusqueda == 1) {
			nodoInicial.getDatosNodo().setHeuristica(calcularHeuristica(nodoInicial));
			nodoInicial.calcularFCostoUniforme();
		}
		if(opcionBusqueda == 2) {
			nodoInicial.getDatosNodo().setHeuristica(calcularHeuristica(nodoInicial));
			nodoInicial.calcularFProfundidadAcotada();
		}
		if(opcionBusqueda == 3) {
			nodoInicial.getDatosNodo().setHeuristica(calcularHeuristica(nodoInicial));
			nodoInicial.calcularfVoraz();
		}
		if(opcionBusqueda == 4) {
			nodoInicial.getDatosNodo().setHeuristica(calcularHeuristica(nodoInicial));
			nodoInicial.calcularFAasterisco();
		}

		return nodoInicial;
	}

	public static String busqueda2(JuegoBotellas problem, int opcionBusqueda) throws NoSuchAlgorithmException {
		boolean seguirBuscando = true;
		String solucion = "";
		Frontera frontera = new Frontera();
		Visitados visitados = new Visitados();
		visitados.crear_vacio();
		frontera.PUSH((makeNode(problem,opcionBusqueda)));
		int contadorID = 0;
		int profundidadAcotada = 1000000;
		while(seguirBuscando) {

			if(frontera.getColaFrontera().isEmpty()) {
				seguirBuscando = false;
				System.out.println("Error. Frontera vacia");
			}
			else {
				if(frontera.getColaFrontera().get(0).getDatosNodo().getProfundidad() == profundidadAcotada) {
					seguirBuscando = false;
				}
				if(esObjetivo(frontera.getColaFrontera().get(0))) {
					seguirBuscando = false;
					System.out.println("Solucion:");
					solucion = imprimirSolucion(frontera.getColaFrontera().get(0));

				}
				else {
					if(!(visitados.getListaVisitados()).isEmpty()) {
						if(visitados.insertar(frontera.getColaFrontera().get(0).getDatosNodo().getEstado())) {
							contadorID = meterSucesoresExpandidosEnFrontera(frontera.POP(), frontera.getColaFrontera(), contadorID, opcionBusqueda);
						}
						else {
							frontera.POP();
						}
					}
					else {
						visitados.insertarEnListaVacia(frontera.getColaFrontera().get(0).getDatosNodo().getEstado());
						contadorID = meterSucesoresExpandidosEnFrontera(frontera.POP(), frontera.getColaFrontera(), contadorID, opcionBusqueda);
					}

				}
			}
		}
		return solucion;
	}

	public static int meterSucesoresExpandidosEnFrontera(Nodo nodo,ArrayList<Nodo> frontera, int contadorID,int opcionBusqueda) {
		ArrayList <Sucesor> sucesoresExpandidos = Sucesores(nodo.getDatosNodo().getEstado());
		Iterator <Sucesor> iteradorSucesores = sucesoresExpandidos.iterator();
		while(iteradorSucesores.hasNext()) {
			Sucesor sucesor = iteradorSucesores.next();
			DatosNodo datosNodo = new DatosNodo (nodo.getID(),nodo.getDatosNodo().getProfundidad()+1,0,sucesor.getNuevoEstado(),sucesor.getAccion(),0);
			contadorID = contadorID + 1;
			Nodo nodoHijo = new Nodo (datosNodo,(contadorID));
			nodoHijo.setPadre(nodo);
			calculoCosteMovimiento(nodoHijo);
			if(opcionBusqueda == 0){
				nodoHijo.calcularFAnchura();
			}
			if(opcionBusqueda == 1){
				nodoHijo.calcularFCostoUniforme();
			}
			if(opcionBusqueda == 2){
				nodoHijo.calcularFProfundidadAcotada();
				ordenarListaNodos(frontera);
			}
			if(opcionBusqueda == 3) {
				nodoHijo.getDatosNodo().setHeuristica(calcularHeuristica(nodoHijo));
				nodoHijo.calcularfVoraz();
				ordenarListaNodos(frontera);
			}
			if(opcionBusqueda == 4) {
				nodoHijo.getDatosNodo().setHeuristica(calcularHeuristica(nodoHijo));
				nodoHijo.calcularFAasterisco();
				ordenarListaNodos(frontera);
			}

			frontera.add(nodoHijo);
		}
		
		return contadorID;
	}

	public static Queue<Nodo> ordenarColaNodosPorF (Queue<Nodo> frontera) {
		Queue<Nodo> fronteraAux = new LinkedList<>();
		ArrayList<Nodo> listaNodosOrdenar = new ArrayList<Nodo>();
		Iterator <Nodo>iteradorNodosCola = frontera.iterator();
		while(iteradorNodosCola.hasNext()) {
			Nodo nodoCola=iteradorNodosCola.next();
			listaNodosOrdenar.add(nodoCola);
		}
		Collections.sort(listaNodosOrdenar, new CustomComparator());
		Iterator <Nodo> iteradorNodosLista = listaNodosOrdenar.iterator();
		while(iteradorNodosLista.hasNext()) {
			Nodo nodoLista = iteradorNodosLista.next();
			fronteraAux.add(nodoLista);
		}
		return fronteraAux;
	}


	public static void calculoCosteMovimiento(Nodo nodoHijo) {		
		float coste = 0;
		float costePadre = nodoHijo.getNodoPadre().getDatosNodo().getCosto();
		coste = costePadre + 1;
		nodoHijo.getDatosNodo().setCosto(coste);

	}



	public static String pasarStringAMd5(String cadena) throws NoSuchAlgorithmException{

		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] messageDigest = md.digest(cadena.getBytes());
		BigInteger number = new BigInteger(1, messageDigest);
		String hashtext = number.toString(16);

		return hashtext;
	}

	public static boolean comprobarNodoExistenteVisitados(ArrayList<String> listamd5Visitados, String nuevomd5) {
		boolean repetido = false;
		Iterator<String> iteradormd5Visitados = listamd5Visitados.iterator();
		while(iteradormd5Visitados.hasNext()) {
			String md5 = iteradormd5Visitados.next();
			if(md5.equals(nuevomd5)) {
				repetido = true;
			}
		}	
		return repetido;
	}

	public static void clonarLista(ArrayList<Botella> ListaBotellas,ArrayList<Botella> ListaAux) {

		Iterator<Botella> iteradorBotellas = ListaBotellas.iterator();
		while(iteradorBotellas.hasNext()) {
			Botella botella = iteradorBotellas.next();
			Stack<int[]> pila = botella.getPilaLiquidos();
			Stack<int[]> pilaAux = new Stack<int[]>();
			String idAux = botella.getID();
			int capacidadAux = botella.getCapacidadMaxima();
			Iterator<int[]> iteradorLiquidos = pila.iterator();
			while(iteradorLiquidos.hasNext()) {
				int[] liquido = iteradorLiquidos.next();
				int color = liquido[0];
				int cantidad = liquido[1];
				int[] liquidoAux = {color, cantidad};
				pilaAux.push(liquidoAux);
			}

			Botella botellaAux = new Botella(idAux,pilaAux, capacidadAux);
			ListaAux.add(botellaAux);

		}		

	}

	public static Botella clonarBotella(Botella botella) {
		Stack<int[]> pila = botella.getPilaLiquidos();
		Stack<int[]> pilaAux = new Stack<int[]>();
		String idAux = botella.getID();
		int capacidadAux = botella.getCapacidadMaxima();
		Iterator<int[]> iteradorLiquidos = pila.iterator();
		while(iteradorLiquidos.hasNext()) {
			int[] liquido = iteradorLiquidos.next();
			int color = liquido[0];
			int cantidad = liquido[1];
			int[] liquidoAux = {color, cantidad};
			pilaAux.push(liquidoAux);
		}

		Botella botellaAux = new Botella(idAux,pilaAux, capacidadAux);
		return botellaAux;
	}

	public static float calcularHeuristica(Nodo nodo) {
		float heuristica = 0;
		ArrayList<Botella> listaBotellas = nodo.getDatosNodo().getEstado().getListaBotellas();
		ArrayList<Integer> listaBotellasVisitados = new ArrayList<Integer>();
		for(int i=0; i<listaBotellas.size();i++) {
			boolean meterBotella = true;
			Stack<int[]> pilaLiquidos = listaBotellas.get(i).getPilaLiquidos();
			int numLiquidos = pilaLiquidos.size();
			if(i==0) {
				if(numLiquidos == 0) {
					heuristica = heuristica + 1;
				}
				else{
					heuristica = heuristica + numLiquidos;
					listaBotellasVisitados.add(i);
				}
				
			}
			else if(pilaLiquidos.isEmpty()) {
				heuristica = heuristica + 1; 
			}
			else {
				int colorCabeceraPila = pilaLiquidos.peek()[0];
				boolean seguir = true;
				for(int j=0;j<listaBotellasVisitados.size() && seguir;j++) {
					if(!listaBotellas.get(listaBotellasVisitados.get(j)).getPilaLiquidos().isEmpty()) {
					int colorCabeceraBotellaVisitada = listaBotellas.get(listaBotellasVisitados.get(j)).getPilaLiquidos().peek()[0];
					if(colorCabeceraPila == colorCabeceraBotellaVisitada) {
						heuristica = heuristica + 1;
						seguir = false;
						meterBotella = false;
					}
					}
				}
				heuristica = heuristica + numLiquidos;
				if(meterBotella) {
					listaBotellasVisitados.add(i);
				}
			}
		}
		heuristica = heuristica - listaBotellas.size();
		return heuristica;
	}

	public static boolean comprobarNumeroDentroLista(ArrayList<Integer> listaEnteros , int numeroComprobar) {
		boolean estaDentro = false;
		for(int i=0;i<listaEnteros.size();i++) {
			if(listaEnteros.get(i) == numeroComprobar) {
				estaDentro = true;
			}
		}
		return estaDentro;
	}

	public static String imprimirSolucion(Nodo nodoSolucion) throws NoSuchAlgorithmException {
		int idNodo = -1;
		String resultado = "";
		Stack<Nodo> pilaNodos = new Stack<Nodo>();
		Nodo nodoAux = nodoSolucion;
		pilaNodos.push(nodoSolucion);
		while(idNodo != 0) {
			if(nodoAux.getID() != 0) {
				nodoAux = nodoAux.getNodoPadre();
				pilaNodos.push(nodoAux);
			}
			else {
				idNodo = 0;
			}

		}
		String id = "";
		String datos = "";
		while(!pilaNodos.isEmpty()) {
			Nodo nodo = pilaNodos.pop();
			id = "[" + nodo.getID() + "]";
			if(nodo.getID()==0) {
				datos = "[" + nodo.getDatosNodo().getCosto() +"," + pasarStringAMd5(JAVAtoStringJSON(nodo.getDatosNodo().getEstado().getListaBotellas())) +","+ "None"+"," +  "None" +","+ nodo.getDatosNodo().getProfundidad() +","+ nodo.getDatosNodo().getHeuristica() +","+ nodo.getDatosNodo().getF() + "]";
				resultado = resultado +id + datos + "\n";
			}
			else {
				datos = "[" + nodo.getDatosNodo().getCosto() +"," + pasarStringAMd5(JAVAtoStringJSON(nodo.getDatosNodo().getEstado().getListaBotellas())) +","+ nodo.getDatosNodo().getIDpadre()+"," + nodo.getDatosNodo().getAccion().imprimirAccion() +","+ nodo.getDatosNodo().getProfundidad() +","+ nodo.getDatosNodo().getHeuristica() +","+ nodo.getDatosNodo().getF() + "]";
				resultado = resultado +id + datos + "\n";
			}

		}
		System.out.println(resultado);
		return resultado;
	}
	public static Stack<int[]> invertirPila(Stack<int[]> pila) {
		Stack<int[]> pilaAux = new Stack<int[]>();
		int contador = pila.size();
		for(int i=0;i<contador;i++) {
			pilaAux.push(pila.pop());
		}
		return pilaAux;

	}

	public static void ordenarListaNodos(List<Nodo> f1) {
		for(int i=0;i<f1.size();i++) {
			for(int j=0;j<f1.size();j++) {
				if(i!=j) {
					if(f1.get(i).getDatosNodo().getF()<f1.get(j).getDatosNodo().getF() && i>j) {
						Nodo aux=f1.get(i);
						f1.remove(i);
						f1.add(j,aux);
					}
					if(f1.get(i).getDatosNodo().getF()>f1.get(j).getDatosNodo().getF() && i<j) {
						Nodo aux=f1.get(j);
						f1.remove(j);
						f1.add(i,aux);
					}
					if(f1.get(i).getDatosNodo().getF()==f1.get(j).getDatosNodo().getF()) {
						if(f1.get(i).getID()<f1.get(j).getID() && i>j) {
							Nodo aux=f1.get(i);
							f1.remove(i);
							f1.add(j,aux);
						}
						if(f1.get(i).getID()>f1.get(j).getID() && i<j) {
							Nodo aux=f1.get(j);
							f1.remove(j);
							f1.add(i,aux);
						}
					}
				}
			}
		}
	}
	public static void pasarSolucionAArchivo(String nombreFicheroDeseado, String solucion) {
		 try {
	            String ruta = "C:\\Users\\rober\\Downloads\\SolucionesPracticaInteligentes\\" + nombreFicheroDeseado;
	            String contenido = solucion;
	            File file = new File(ruta);
	            // Si el archivo no existe es creado
	            if (!file.exists()) {
	                file.createNewFile();
	            }
	            FileWriter fw = new FileWriter(file);
	            BufferedWriter bw = new BufferedWriter(fw);
	            bw.write(contenido);
	            bw.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}