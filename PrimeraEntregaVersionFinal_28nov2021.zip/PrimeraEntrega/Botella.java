package PrimeraEntrega;


import java.util.Stack;

public class Botella  {
	
	private String ID;
	private Stack<int[]> pilaLiquidos;
	private int capacidadMaxima;
	
	public Botella(String id,Stack<int[]> liquidos,int capMaxima) {
		ID=id;
		pilaLiquidos=liquidos;
		capacidadMaxima=capMaxima;
		
	}
	
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public Stack<int[]> getPilaLiquidos() {
		return pilaLiquidos;
	}
	public void setPilaLiquidos(Stack<int[]> pilaLiquidos) {
		this.pilaLiquidos = pilaLiquidos;
	}

	public void setCapacidadMaxima(int capacidadMaxima) {
		this.capacidadMaxima = capacidadMaxima;
	}

	public int getCapacidadMaxima() {
		return capacidadMaxima;
	}
	
	public static Botella copy( Botella other ) {
       
        Botella newUser = new Botella(" ", other.pilaLiquidos, 0);
		newUser.ID = other.ID;
        newUser.pilaLiquidos = other.pilaLiquidos;
        newUser.capacidadMaxima=other.capacidadMaxima;
        return newUser;
   }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ID == null) ? 0 : ID.hashCode());
		result = prime * result + capacidadMaxima;
		result = prime * result + ((pilaLiquidos == null) ? 0 : pilaLiquidos.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Botella other = (Botella) obj;
		if (ID == null) {
			if (other.ID != null)
				return false;
		} else if (!ID.equals(other.ID))
			return false;
		if (capacidadMaxima != other.capacidadMaxima)
			return false;
		if (pilaLiquidos == null) {
			if (other.pilaLiquidos != null)
				return false;
		} else if (!pilaLiquidos.equals(other.pilaLiquidos))
			return false;
		return true;
	}
}

