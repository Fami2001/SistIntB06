package PrimeraEntrega;


public class Accion {

	private Botella botellaOrigen;
	private Botella botellaDestino;
	private int cantidad;
	
	public Accion(Botella botellaOrigen, Botella botellaDestino, int cantidad) {
		super();
		this.botellaOrigen = botellaOrigen;
		this.botellaDestino = botellaDestino;
		this.cantidad = cantidad;
	}
	
	public Botella getBotellaDestino() {
		return botellaDestino;
	}
	public Botella getBotellaOrigen() {
		return botellaOrigen;
	} 
	public float getCantidad() {
		return cantidad;
	}

	
	public void setBotellaDestino(Botella botellaDestino) {
		this.botellaDestino = botellaDestino;
	}
	public void setBotellaOrigen(Botella botellaOrigen) {
		this.botellaOrigen = botellaOrigen;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	public String imprimirAccion() {
		return "(" + botellaOrigen.getID()+ ", " + botellaDestino.getID() + ", " + cantidad + ")";
	}
	
}