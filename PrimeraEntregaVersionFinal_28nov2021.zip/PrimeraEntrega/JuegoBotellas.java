package PrimeraEntrega;


import com.google.gson.Gson;

public class JuegoBotellas{
	
	private  String id;
	private int tamanioBotella;
	private String jsonState;
	
	
	public JuegoBotellas(String id, int tamanioBotella, String jsonState) {
		super();
		this.id = id;
		this.tamanioBotella = tamanioBotella;
		this.jsonState = jsonState;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	public String getId() {
		return id;
	}
	public void setJsonState(String jsonState) {
		this.jsonState = jsonState;
	}
	public String getJsonState() {
		return jsonState;
	}
	public void setTamanioBotella(int tamanioBotella) {
		this.tamanioBotella = tamanioBotella;
	}
	public int getTamanioBotella() {
		return tamanioBotella;
	}
	
	
	
	
	
	
	
	
	
	
	

}
