package PrimeraEntrega;

import java.util.ArrayList;
import java.util.Stack;

public class Pruebas {

	public static void main (String[]args) {
		
		int [] liquido1 = {1,2};
		int [] liquido2 = {2,2};
		int [] liquido3 = {3,3};
		
		int [] liquido4 = {7,2};
		int [] liquido5 = {4,2};
		int [] liquido6 = {8,3};
		
		int [] liquido7 = {1,2};
		int [] liquido8 = {2,2};
		int [] liquido9 = {3,3};
		
		int [] liquido10 = {7,2};
		int [] liquido11 = {4,2};
		int [] liquido12 = {8,3};
		
		Stack<int[]> pila1= new Stack<int[]>();
		Stack<int[]> pila2= new Stack<int[]>();
		Stack<int[]> pila3= new Stack<int[]>();
		Stack<int[]> pila4= new Stack<int[]>();
		
		pila1.push(liquido1);
		pila1.push(liquido2);
		pila1.push(liquido3);
		
		pila2.push(liquido4);
		pila2.push(liquido5);
		pila2.push(liquido6);
		
		pila3.push(liquido7);
		pila3.push(liquido8);
		pila3.push(liquido9);
		
		pila4.push(liquido10);
		pila4.push(liquido11);
		pila4.push(liquido12);
		
		ArrayList<Stack<int[]>> lista1 = new ArrayList<Stack<int[]>>();
		ArrayList<Stack<int[]>> lista2 = new ArrayList<Stack<int[]>>();
		
		lista1.add(pila1);
		lista1.add(pila2);
		
		lista2.add(pila3);
		lista2.add(pila4);
		
		boolean iguales=false;
		iguales= lista1.equals(lista2);
		System.out.println(iguales);
	}
}
