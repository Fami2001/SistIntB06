package PrimeraEntrega;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Visitados {

	private ArrayList<Estado> listaVisitados;
	private ArrayList<String> listamd5Visitados;
	
	public Visitados() {
		super();

	}
	
	public void crear_vacio() {
		listaVisitados = new ArrayList<Estado>();
		listamd5Visitados = new ArrayList<String>();


	}
	
	public ArrayList<Estado> getListaVisitados() {
		return listaVisitados;
	}

	public void setListaVisitados(ArrayList<Estado> listaVisitados) {
		this.listaVisitados = listaVisitados;
	}

	public boolean insertar (Estado estado) throws NoSuchAlgorithmException {
		boolean puedeSerInsertado = false;
		puedeSerInsertado = !pertenece(estado);
		if(puedeSerInsertado) {
			String md5 = pasarStringAMd5(JAVAtoStringJSON(estado)) ;
			listaVisitados.add(estado);
			listamd5Visitados.add(md5);
		}
		return puedeSerInsertado;
	}
	
	public void insertarEnListaVacia(Estado estado) throws NoSuchAlgorithmException {
		String md5 = pasarStringAMd5(JAVAtoStringJSON(estado)) ;
		listaVisitados.add(estado);
		listamd5Visitados.add(md5);
	}
	
	public boolean pertenece (Estado estado) throws NoSuchAlgorithmException {
		boolean pertenece = false;
		if(comprobarNodoExistenteVisitados(estado)) {
			pertenece = true;
		}
		
		
		
		
		return pertenece;
	}
	
	public  boolean comprobarNodoExistenteVisitados(Estado estado) throws NoSuchAlgorithmException {
		String nuevomd5 = pasarStringAMd5(JAVAtoStringJSON(estado)) ;
		boolean repetido = false;
		Iterator<String> iteradormd5Visitados = listamd5Visitados.iterator();
		while(iteradormd5Visitados.hasNext()) {
			String md5lista = iteradormd5Visitados.next();
			if(md5lista.equals(nuevomd5)) {
				repetido = true;
			}
		}	
		return repetido;
	}
	
	
	
	public  String pasarStringAMd5(String cadena) throws NoSuchAlgorithmException{

		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] messageDigest = md.digest(cadena.getBytes());
		BigInteger number = new BigInteger(1, messageDigest);
		String hashtext = number.toString(16);

		return hashtext;
	}
	
	public static String JAVAtoStringJSON(Estado estado) {
		ArrayList<Botella> listaBotellas = estado.getListaBotellas();
        String stringJson = "";
        ArrayList<Stack<int[]>> listaPilasBotellas = new ArrayList<Stack<int[]>>();
        Iterator<Botella> iteradorBotellas = listaBotellas.iterator();
        while(iteradorBotellas.hasNext()) {
            Botella botella = clonarBotella(iteradorBotellas.next());
            listaPilasBotellas.add(invertirPila(botella.getPilaLiquidos()));
        }
        Gson gson = new Gson();
        final java.lang.reflect.Type tipoListaPilasBotellas =  new TypeToken<List<Stack<int[]>>>(){}.getType();
        stringJson =  gson.toJson(listaPilasBotellas);
        return stringJson;
    }
	
	public static Botella clonarBotella(Botella botella) {
		Stack<int[]> pila = botella.getPilaLiquidos();
		Stack<int[]> pilaAux = new Stack<int[]>();
		String idAux = botella.getID();
		int capacidadAux = botella.getCapacidadMaxima();
		Iterator<int[]> iteradorLiquidos = pila.iterator();
		while(iteradorLiquidos.hasNext()) {
			int[] liquido = iteradorLiquidos.next();
			int color = liquido[0];
			int cantidad = liquido[1];
			int[] liquidoAux = {color, cantidad};
			pilaAux.push(liquidoAux);
		}

		Botella botellaAux = new Botella(idAux,pilaAux, capacidadAux);
		return botellaAux;
	}
	
	public static Stack<int[]> invertirPila(Stack<int[]> pila ) {
		Stack<int[]> pilaAux = (Stack<int[]>)pila.clone();
		Stack<int[]> pilaAux2 = new Stack<int[]>();
		while(!pilaAux.isEmpty()) {
			pilaAux2.push(pilaAux.pop());
		}
		return pilaAux2;

	}
}
