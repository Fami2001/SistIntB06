package PrimeraEntrega;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class Frontera {

	private ArrayList<Nodo> colaFrontera;
	
	public Frontera() {
		colaFrontera = new ArrayList<Nodo>();
	}
	
	public Nodo POP() {
		return colaFrontera.remove(0);
	}
	
	public void PUSH(Nodo n) {
		colaFrontera.add(n);
	}

	public ArrayList<Nodo> getColaFrontera() {
		return colaFrontera;
	}

	public void setColaFrontera(ArrayList<Nodo> colaFrontera) {
		this.colaFrontera = colaFrontera;
	}
	
}
