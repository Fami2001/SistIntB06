package PrimeraEntrega;
import java.util.*;
public class Nodo {
	private int ID;
	private DatosNodo datosNodo;
	private Nodo nodoPadre;

	public Nodo(DatosNodo datosNodo, int ID) {
		super();
		this.ID=ID;
		this.datosNodo = datosNodo;
	}
	
	public int getID() {
		return ID;
	}
	
	public void setPadre(Nodo padre) {
		nodoPadre = padre;
	}
	public float getfPadre() {
		return nodoPadre.getDatosNodo().getF();
	}
	public void setID(int iD) {
		ID = iD;
	}
	
	public DatosNodo getDatosNodo() {
		return datosNodo;
	}
	
	public void setDatosNodo(DatosNodo datosNodo) {
		this.datosNodo = datosNodo;
	}
	
	public void calcularFAnchura() {
		float f = getfPadre() + 1;
		datosNodo.setF(f);
	}
	
	public void calcularFCostoUniforme() {
		datosNodo.setF(datosNodo.getCosto()); 
	}
	
	public Nodo getNodoPadre() {
		return nodoPadre;
	}

	public void setNodoPadre(Nodo nodoPadre) {
		this.nodoPadre = nodoPadre;
	}

	public void calcularFProfundidadAcotada() {
		float f;
		if(datosNodo.getProfundidad()==0) {
			f=1;
		}
		else {
			f=(float) (1.0/(datosNodo.getProfundidad()+1.0));
		}
		datosNodo.setF(f);
	}
	
	public void calcularfRandom() {
        float f;
        f=(float) Math.random()*1001;
    }
	
	public void calcularfVoraz() {
		float f;
		f = datosNodo.getHeuristica();
		datosNodo.setF(f);
	}
	
	public void calcularFAasterisco() {
		float f;
		f = datosNodo.getHeuristica() + datosNodo.getCosto();
		datosNodo.setF(f);
	}
	
}
