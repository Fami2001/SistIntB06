package PrimeraEntrega;

import java.util.ArrayList;

public class Sucesor implements Comparable<Sucesor>{

	private Accion accion;
	private Estado nuevoEstado;
	private float costo;
	
	public Sucesor(Accion accion, Estado nuevoEstado, float costo) {
		super();
		this.accion = accion;
		this.nuevoEstado = nuevoEstado;
		this.costo = costo;
	}
	
	public void setAccion(Accion accion) {
		this.accion = accion;
	}
	
	public void setCosto(float costo) {
		this.costo = costo;
	}
	
	public void setNuevoEstado(Estado nuevoEstado) {
		this.nuevoEstado = nuevoEstado;
	}
	
	public Accion getAccion() {
		return accion;
	}
	
	public float getCosto() {
		return costo;
	}
	
	public Estado getNuevoEstado() {
		return nuevoEstado;
	}

	@Override
	public int compareTo(Sucesor arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
	
		
}
