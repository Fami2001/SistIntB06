package PrimeraEntrega;

import java.util.ArrayList;

public class Estado {

	private ArrayList<Botella> listaBotellas;
	private float costeAcumulado;
	private float coste;
	
	public Estado(ArrayList<Botella> listaBotellas) {
		super();
		this.listaBotellas = listaBotellas;
		this.costeAcumulado = 0;
	}
	
	public float getCosteAcumulado() {
		return costeAcumulado;
	}
	
	public void setCosteAcumulado(int costeAcumulado) {
		this.costeAcumulado = costeAcumulado;
	}
	
	public ArrayList<Botella> getListaBotellas() {
		return listaBotellas;
	}
	
	public void calculoCoste(String IDnodo) {
		coste=1;
		costeAcumulado = costeAcumulado + coste;
	}
	
	public static Estado copia(Estado estadoNodoInicial) {
		ArrayList<Botella> aux = null;
		Estado Copia=new Estado(aux);
		Copia.getListaBotellas().clear();
		for (Botella botella : estadoNodoInicial.getListaBotellas()) {
			ArrayList <Integer> color=new ArrayList();
			ArrayList <Integer> cantidad=new ArrayList();
			while(!botella.getPilaLiquidos().isEmpty()) {
				int[] auxiliar=botella.getPilaLiquidos().pop();
				color.add(auxiliar[0]);
				cantidad.add(auxiliar[1]);
			}
			for(int i=color.size()-1;i>=0;i--){
				
			}
		}
		return Copia;	
}
}

