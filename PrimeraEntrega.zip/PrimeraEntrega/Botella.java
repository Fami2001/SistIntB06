package PrimeraEntrega;

import java.util.Stack;

public class Botella  {
	
	private String ID;
	private Stack<int[]> pilaLiquidos;
	private int capacidadMaxima;
	
	public Botella(String id,Stack<int[]> liquidos,int capMaxima) {
		ID=id;
		pilaLiquidos=liquidos;
		capacidadMaxima=capMaxima;
		
	}
	
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public Stack<int[]> getPilaLiquidos() {
		return pilaLiquidos;
	}
	public int getCapacidadMaxima() {
		return capacidadMaxima;
	}
}
