package PrimeraEntrega;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jdi.Type;



public class Main {
	public static Scanner TECLADO=new Scanner(System.in);
	public static void main(String[]args) {

		System.out.println("Introduzca la cadena String JSON");
		String cadenaJSON=TECLADO.nextLine();

		ArrayList<Botella> listaBotellas = new ArrayList<Botella>();
		JSONtoJAVA(listaBotellas,cadenaJSON);


		System.out.println("Pasando a cadena JSON............................");

		Accion(listaBotellas.get(0), listaBotellas.get(5), 5);
		JAVAtoStringJSON(listaBotellas);




	}

	public static void JSONtoJAVA(ArrayList<Botella> listaBotellas,String cadenaJSON) {
		Gson gson = new Gson();
		final java.lang.reflect.Type tipoListaPilasBotellas =  new TypeToken<List<Stack<int[]>>>(){}.getType();
		ArrayList<Stack<int[]>> listaPilasJSONtoJava= gson.fromJson(cadenaJSON, (java.lang.reflect.Type) tipoListaPilasBotellas);

		Iterator<Stack<int[]>> iteradorPilas = listaPilasJSONtoJava.iterator();
		int contadorID=0;
		int capacidadMaximaBotella = 0;
		while(iteradorPilas.hasNext()) {
			Stack<int[]> botellaLiquidos = iteradorPilas.next();
			boolean capacidadMaximaCorrecta=false;
			while(!capacidadMaximaCorrecta) {
				System.out.println("Introduzca la capacidad maxima de la botella con ID="+contadorID+", dicha cantidad debe ser mayor o igual a la cantidad de liquido que contiene, es decir: "+calcularCantidadLiquidoPila(botellaLiquidos)+"");
				capacidadMaximaBotella=TECLADO.nextInt();
				if(capacidadMaximaBotella>=calcularCantidadLiquidoPila(botellaLiquidos)) {
					capacidadMaximaCorrecta=true;
				}
				else {
					System.out.println("Capacidad maxima inferior a la cantidad de liquido que ya contiene la botella");
				}
			}

			Botella botella=new Botella(String.valueOf(contadorID),invertirPila(botellaLiquidos),capacidadMaximaBotella);
			contadorID++;
			listaBotellas.add(botella);
		}
	}

	public static void JAVAtoStringJSON(ArrayList<Botella> listaBotellas) {
		ArrayList<Stack<int[]>> listaPilasBotellas = new ArrayList<Stack<int[]>>();
		Iterator<Botella> iteradorBotellas = listaBotellas.iterator();
		while(iteradorBotellas.hasNext()) {
			Botella botella = iteradorBotellas.next();
			listaPilasBotellas.add(invertirPila(botella.getPilaLiquidos()));
		}
		Gson gson = new Gson();
		final java.lang.reflect.Type tipoListaPilasBotellas =  new TypeToken<List<Stack<int[]>>>(){}.getType();
		System.out.println( gson.toJson(listaPilasBotellas) );	
	}

	public static int calcularCantidadLiquidoPila(Stack<int[]> botella) {
		Iterator<int[]> iteradorLiquidos = botella.iterator();
		int contadorCantidad=0;
		while(iteradorLiquidos.hasNext()) {
			int[] liquido = iteradorLiquidos.next();
			contadorCantidad = contadorCantidad + liquido[1];
		}
		return contadorCantidad;
	}



	public static boolean  ES_AccionPosible (Botella Botella_origen, Botella Botella_destino, int cantidad) {
		boolean esPosible=false;
		if(calcularCantidadLiquidoPila(Botella_destino.getPilaLiquidos()) + cantidad<=Botella_destino.getCapacidadMaxima()) {
			esPosible=true;
		}
		return esPosible;
	}

	public static void Accion (Botella Botella_origen, Botella Botella_destino, int cantidad) {
		if(ES_AccionPosible(Botella_origen,Botella_destino,cantidad)) {
			int cantidadRestanteRellenar=cantidad;
			while(cantidadRestanteRellenar>0) {
				int[] liquido = Botella_origen.getPilaLiquidos().pop();

				if(liquido[1]>cantidadRestanteRellenar && cantidadRestanteRellenar!=0) {
					if(!Botella_destino.getPilaLiquidos().isEmpty()) {
						if(Botella_destino.getPilaLiquidos().peek()[0] == liquido[0]) {
						int [] liquidoBotellaDestino = {liquido[0],liquido[1]-(liquido[1]-cantidadRestanteRellenar)};
						int [] liquidoLlenar= {liquidoBotellaDestino[0],liquidoBotellaDestino[1] + Botella_destino.getPilaLiquidos().pop()[1]};	
						Botella_destino.getPilaLiquidos().push(liquidoLlenar);
						int cantidadSobra=liquido[1] - cantidadRestanteRellenar;
						cantidadRestanteRellenar = cantidadRestanteRellenar - liquidoBotellaDestino[1];
						int [] liquidoSobrante = {liquido[0],cantidadSobra};
						Botella_origen.getPilaLiquidos().push(liquidoSobrante);
						}
					}
					else {
						int [] liquidoBotellaDestino = {liquido[0],liquido[1]-(liquido[1]-cantidadRestanteRellenar)};
						Botella_destino.getPilaLiquidos().push(liquidoBotellaDestino);
						int cantidadSobra=liquido[1] - cantidadRestanteRellenar;
						cantidadRestanteRellenar = cantidadRestanteRellenar - liquidoBotellaDestino[1];
						int [] liquidoSobrante = {liquido[0],cantidadSobra};
						Botella_origen.getPilaLiquidos().push(liquidoSobrante);
					}
				}		
				else if(Botella_destino.getPilaLiquidos().isEmpty()) {
					Botella_destino.getPilaLiquidos().push(liquido);
					cantidadRestanteRellenar = cantidadRestanteRellenar - liquido[1];
				}
				else if (Botella_destino.getPilaLiquidos().peek()[0] == liquido[0]){

					int [] liquidoLlenar= {liquido[0],liquido[1] + Botella_destino.getPilaLiquidos().pop()[1]};						
					Botella_destino.getPilaLiquidos().push(liquidoLlenar);
					cantidadRestanteRellenar = cantidadRestanteRellenar - liquido[1];
				}
				else {
					Botella_destino.getPilaLiquidos().push(liquido);
					cantidadRestanteRellenar = cantidadRestanteRellenar - liquido[1];
				}
			}
		}
	}



	public static Stack<int[]> invertirPila(Stack<int[]> pila ) {
		Stack<int[]> pilaAux = (Stack<int[]>)pila.clone();
		Stack<int[]> pilaAux2 = new Stack<int[]>();
		while(!pilaAux.isEmpty()) {
			pilaAux2.push(pilaAux.pop());
		}
		return pilaAux2;

	}




}
